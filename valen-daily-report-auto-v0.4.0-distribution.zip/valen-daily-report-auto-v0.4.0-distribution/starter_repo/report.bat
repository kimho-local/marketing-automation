@echo off
REM ============================================================
REM 데일리 리포트 실행 (브랜드 자동 선택)
REM ============================================================
REM 사용법:
REM   report.bat                       어제자 리포트 (기본 브랜드)
REM   report.bat 2026-04-27            특정 날짜
REM   report.bat 2026-04-27 renk       특정 날짜 + 브랜드 지정
REM   report.bat - serene              어제자 + 다른 브랜드
REM
REM 기본 브랜드는 .env 파일의 DEFAULT_BRAND 또는 첫 번째 brand_config 파일
REM ============================================================

cd /d "%~dp0"

REM 인자 파싱
set "DATE_ARG=%~1"
set "BRAND_ARG=%~2"

REM 기본 브랜드 결정 (.env > 첫 번째 yaml)
if "%BRAND_ARG%"=="" (
    if exist .env (
        for /f "tokens=2 delims==" %%a in ('findstr /b "DEFAULT_BRAND=" .env') do set "BRAND_ARG=%%a"
    )
)
if "%BRAND_ARG%"=="" (
    for %%f in (brand_config\*.yaml) do (
        if /i not "%%~xf"==".example" (
            set "BRAND_ARG=%%~nf"
            goto :brand_set
        )
    )
)
:brand_set

REM 실행
if "%DATE_ARG%"=="" (
    py scripts\run_daily.py --brand %BRAND_ARG%
) else if "%DATE_ARG%"=="-" (
    py scripts\run_daily.py --brand %BRAND_ARG%
) else (
    py scripts\run_daily.py --brand %BRAND_ARG% --date %DATE_ARG%
)

pause
