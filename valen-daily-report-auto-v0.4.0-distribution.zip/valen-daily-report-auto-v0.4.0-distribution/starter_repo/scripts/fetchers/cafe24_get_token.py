#!/usr/bin/env python3
"""
카페24 Access Token 발급 / 갱신 (브랜드별)
==========================================
사용법:
  # 1. 신규 발급 (Authorization Code 교환)
  python -m scripts.fetchers.cafe24_get_token --brand renk
  → 프롬프트에 Authorization Code 입력

  # 2. 토큰 수동 갱신 (만료 시 fetcher 가 자동 갱신하므로 수동 사용 거의 불필요)
  python -m scripts.fetchers.cafe24_get_token --brand renk --refresh

토큰 파일 (config/{브랜드}_cafe24_token.json) 형식:
  {
    "client_id":     "Cafe24 앱 client_id",
    "client_secret": "Cafe24 앱 client_secret",
    "redirect_uri":  "Cafe24 앱에 등록된 redirect URL",
    "access_token":  "...",           ← Authorization Code 교환 후 자동 채워짐
    "refresh_token": "...",           ← 자동
    "expires_at":    "2026-04-28T...",← 자동
    "scopes":        [...]            ← 자동
  }

처음 셋업 시:
  1. 본인 브랜드의 Cafe24 개발자센터에서 앱 생성
  2. config/{브랜드}_cafe24_token.json 파일을 다음 3개 키만 담아 직접 생성:
     {
       "client_id":     "...",
       "client_secret": "...",
       "redirect_uri":  "..."
     }
  3. brand_config/{브랜드}.yaml 의 stores.cafe24.mall_id 입력
  4. 브라우저에서 Authorization Code 발급 후 이 스크립트 실행
"""

import os
import sys
import urllib.request
import urllib.parse
import urllib.error
import json
import base64
import argparse
from pathlib import Path

# 모듈 직접 실행 지원
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from utils.config_loader import load_brand, secret_path
from utils.active_brand import set_active


def _build_endpoints(brand):
    mall_id = brand.stores.cafe24.mall_id
    if not mall_id:
        print(f"[ERROR] brand_config/{brand.brand.code}.yaml 의 stores.cafe24.mall_id 누락")
        sys.exit(1)
    return {
        'token_url': f'https://{mall_id}.cafe24api.com/api/v2/oauth/token',
    }


def _load_token_file(token_file: Path) -> dict:
    """
    토큰 파일 로드.
    파일이 없으면 빈 dict, 있어도 client_id 누락 시 친절한 안내.
    """
    if not token_file.exists():
        print(f"[ERROR] {token_file} 파일 없음.")
        print(f"        먼저 다음 형식으로 파일을 생성하세요:")
        print(f"        {{")
        print(f'          "client_id":     "Cafe24 앱 client_id",')
        print(f'          "client_secret": "Cafe24 앱 client_secret",')
        print(f'          "redirect_uri":  "Cafe24 앱 redirect URL"')
        print(f"        }}")
        sys.exit(1)

    with open(token_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    missing = [k for k in ('client_id', 'client_secret', 'redirect_uri') if not data.get(k)]
    if missing:
        print(f"[ERROR] {token_file} 에 필수 필드 누락: {', '.join(missing)}")
        sys.exit(1)

    return data


def _save_merged(token_file: Path, prior: dict, new_response: dict):
    """API 응답 + 기존 client 정보 병합 저장"""
    preserved = {
        k: prior.get(k)
        for k in ('client_id', 'client_secret', 'redirect_uri')
    }
    merged = {**preserved, **new_response}
    with open(token_file, 'w', encoding='utf-8') as f:
        json.dump(merged, f, indent=2, ensure_ascii=False)
    return merged


def exchange_code(brand, auth_code: str) -> dict:
    """Authorization Code → Access Token 교환"""
    endpoints = _build_endpoints(brand)
    token_file = Path(secret_path(brand.brand.code, 'cafe24'))
    prior = _load_token_file(token_file)

    credentials = base64.b64encode(
        f"{prior['client_id']}:{prior['client_secret']}".encode()
    ).decode()

    data = urllib.parse.urlencode({
        'grant_type': 'authorization_code',
        'code': auth_code,
        'redirect_uri': prior['redirect_uri'],
    }).encode()

    req = urllib.request.Request(
        endpoints['token_url'],
        data=data,
        headers={
            'Authorization': f'Basic {credentials}',
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode())
            print("\n✓ 토큰 발급 성공!")
            print(f"  Access Token:  {result.get('access_token', '')[:20]}...")
            print(f"  Refresh Token: {result.get('refresh_token', '')[:20]}...")
            print(f"  만료:         {result.get('expires_at', '?')}")
            print(f"  Scope:        {result.get('scopes', [])}")

            merged = _save_merged(token_file, prior, result)
            print(f"\n→ 토큰 저장 완료: {token_file}")
            return merged
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', errors='replace')
        print(f"\n✗ 토큰 발급 실패 (HTTP {e.code})")
        print(f"  응답: {body}")
        return {}


def refresh_token(brand) -> dict:
    """Refresh Token 으로 Access Token 갱신"""
    endpoints = _build_endpoints(brand)
    token_file = Path(secret_path(brand.brand.code, 'cafe24'))
    prior = _load_token_file(token_file)

    rt = prior.get('refresh_token', '')
    if not rt:
        print("✗ Refresh Token 없음. --brand 옵션과 함께 신규 발급 절차를 진행하세요.")
        return {}

    credentials = base64.b64encode(
        f"{prior['client_id']}:{prior['client_secret']}".encode()
    ).decode()

    data = urllib.parse.urlencode({
        'grant_type': 'refresh_token',
        'refresh_token': rt,
    }).encode()

    req = urllib.request.Request(
        endpoints['token_url'],
        data=data,
        headers={
            'Authorization': f'Basic {credentials}',
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode())
            print("\n✓ 토큰 갱신 성공!")
            print(f"  Access Token: {result.get('access_token', '')[:20]}...")
            print(f"  만료:        {result.get('expires_at', '?')}")
            merged = _save_merged(token_file, prior, result)
            print(f"→ 토큰 저장 완료: {token_file}")
            return merged
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', errors='replace')
        print(f"\n✗ 갱신 실패 (HTTP {e.code}): {body}")
        return {}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='카페24 토큰 발급 / 갱신')
    parser.add_argument('--brand', required=True, help='브랜드 코드 (예: renk)')
    parser.add_argument('--refresh', action='store_true', help='기존 refresh_token 으로 갱신')
    args = parser.parse_args()

    brand = load_brand(args.brand)
    set_active(brand)

    if args.refresh:
        refresh_token(brand)
    else:
        code = input("Authorization Code 입력 (브라우저 콜백 URL의 code= 뒤 값): ").strip()
        if code:
            exchange_code(brand, code)
        else:
            print("코드를 입력하지 않았습니다.")
            sys.exit(1)
