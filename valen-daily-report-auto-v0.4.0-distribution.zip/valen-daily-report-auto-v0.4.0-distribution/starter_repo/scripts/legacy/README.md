# legacy/

호진님 기존 운영에서 사용하던 CSV 기입 도구.

## meta_processor.py
Re:NK 운영 초기에 사용하던 CSV 리포트 자동 기입 모듈.
v3 starter repo 의 메인 파이프라인(run_daily.py)에서는 시트 + docx 가
주력 출력이고 CSV 기입은 더이상 사용하지 않습니다.

필요 시 `python scripts/legacy/meta_processor.py --help` 로 단독 실행 가능.
