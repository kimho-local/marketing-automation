"""
Raw API 응답 저장 유틸 (검증·디버깅용)
======================================
fetcher 모듈에서 호출하여 API 원본 응답을 파일로 보존.

주 용도:
- starter ↔ 호진님 기존 환경 산출물 검증 (Phase 1)
- 운영 중 수치 이상 발생 시 raw 응답으로 원인 추적
- 매체사 API 응답 스키마 변경 추적

활성화 방법:
- 환경변수 VALEN_DUMP_RAW=1
- 또는 run_daily.py --dump-raw 옵션

저장 위치: data/raw/{date}/{매체}_{식별자}.json
"""

import os
import json
from pathlib import Path
from datetime import datetime
from typing import Any


def is_dump_enabled() -> bool:
    """raw 덤프 활성 여부 (환경변수 기반)"""
    return os.environ.get('VALEN_DUMP_RAW', '0') == '1'


def enable_dump():
    """프로세스 내에서 raw 덤프 활성화"""
    os.environ['VALEN_DUMP_RAW'] = '1'


def get_raw_dir(date_str: str = None) -> Path:
    """raw 저장 폴더 경로 (날짜별 분리)"""
    root = Path(__file__).resolve().parents[2]
    raw_root = root / 'data' / 'raw'
    if date_str:
        raw_root = raw_root / date_str
    raw_root.mkdir(parents=True, exist_ok=True)
    return raw_root


def dump(channel: str, identifier: str, data: Any, date_str: str = None) -> str:
    """
    raw 응답을 JSON 파일로 저장.

    Args:
        channel: 매체 이름 (meta, cafe24, naver_sa, ...)
        identifier: 식별자 (account_id, mall_id, customer_id 등 또는 'default')
        data: 저장할 데이터 (dict, list, str)
        date_str: 날짜 (YYYY-MM-DD), 미지정 시 오늘 날짜

    Returns:
        저장된 파일 경로 (활성화 안 됐으면 빈 문자열)
    """
    if not is_dump_enabled():
        return ''

    if not date_str:
        date_str = datetime.now().strftime('%Y-%m-%d')

    raw_dir = get_raw_dir(date_str)

    # 파일명: {매체}_{식별자}_{타임스탬프}.json
    safe_id = str(identifier).replace('/', '_').replace(':', '_')[:50]
    ts = datetime.now().strftime('%H%M%S')
    filename = f"{channel}_{safe_id}_{ts}.json"
    filepath = raw_dir / filename

    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        return str(filepath)
    except Exception as e:
        # 덤프 실패가 본 작업을 중단시키면 안 됨
        print(f"[WARN] raw dump 실패 ({channel}/{identifier}): {e}")
        return ''


def dump_text(channel: str, identifier: str, content: str, ext: str = 'txt', date_str: str = None) -> str:
    """JSON 이 아닌 raw text/csv/xml 등 저장"""
    if not is_dump_enabled():
        return ''

    if not date_str:
        date_str = datetime.now().strftime('%Y-%m-%d')

    raw_dir = get_raw_dir(date_str)
    safe_id = str(identifier).replace('/', '_').replace(':', '_')[:50]
    ts = datetime.now().strftime('%H%M%S')
    filename = f"{channel}_{safe_id}_{ts}.{ext}"
    filepath = raw_dir / filename

    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return str(filepath)
    except Exception as e:
        print(f"[WARN] raw text dump 실패 ({channel}/{identifier}): {e}")
        return ''
