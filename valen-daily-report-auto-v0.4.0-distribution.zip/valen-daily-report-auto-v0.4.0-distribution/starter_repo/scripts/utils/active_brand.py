#!/usr/bin/env python3
"""
프로세스 단위 브랜드 컨텍스트
=====================================
run_daily.py 가 시작 시 한 번 set_active() 호출하면,
이후 모든 fetcher/writer/publisher 가 동일 brand 를 참조.

한 프로세스 = 한 브랜드 처리 원칙.
(동시에 여러 브랜드를 한 프로세스에서 처리할 일 없음 — report.bat 한 번 실행 = 한 브랜드)
"""

from typing import Optional
from types import SimpleNamespace


_brand: Optional[SimpleNamespace] = None


def set_active(brand: SimpleNamespace) -> None:
    """run_daily.py에서 최초 1회 호출"""
    global _brand
    _brand = brand


def get_brand() -> SimpleNamespace:
    """
    fetcher/writer/publisher 모듈에서 호출.
    set_active()를 먼저 호출하지 않은 상태라면 명확한 에러.
    """
    if _brand is None:
        raise RuntimeError(
            "브랜드 컨텍스트 미초기화. "
            "run_daily.py 또는 진입점에서 active_brand.set_active(brand)를 먼저 호출하세요."
        )
    return _brand


def is_active() -> bool:
    return _brand is not None
