#!/usr/bin/env python3
"""
일관된 로그 포맷
=====================================
호진님 run_daily.py의 log() 함수를 모듈로 분리.
모든 fetcher/writer/publisher 에서 동일한 포맷으로 출력.

사용법:
    from utils.logger import log
    log("Meta API 수집 중...", "INFO")
    log("토큰 만료", "WARN")
    log("API 호출 실패", "ERROR")
"""

from datetime import datetime


def log(msg: str, level: str = 'INFO') -> str:
    """
    [YYYY-MM-DD HH:MM:SS] [LEVEL] msg 형식으로 출력.
    반환값은 동일한 라인 (logs/ 파일 기록 등에 활용 가능).
    """
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{timestamp}] [{level}] {msg}"
    print(line)
    return line


def section(title: str):
    """구분선 + 제목 출력 (Step 1, Step 2 등)"""
    bar = "━" * 40
    log(bar)
    log(title)
    log(bar)
