#!/usr/bin/env python3
"""
brand_config + 시크릿 통합 로더
=====================================
brand_config/{brand_code}.yaml 로드 + config/{brand_code}_*.json 자동 매핑

사용법:
    from utils.config_loader import load_brand
    brand = load_brand('renk')
    if brand.channels.meta.enabled:
        token = brand.secrets.meta['access_token']

새 브랜드 추가 시 이 파일은 수정 불필요.
brand_config/{새브랜드}.yaml 작성 + config/{새브랜드}_*.json 배치만 하면 동작.
"""

import os
import json
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Optional


# ============================================================
# 경로 정의
# ============================================================
# 이 파일 기준 2단계 위가 starter_repo 루트
ROOT_DIR = Path(__file__).resolve().parents[2]
BRAND_CONFIG_DIR = ROOT_DIR / 'brand_config'
SECRETS_DIR = ROOT_DIR / 'config'


# ============================================================
# YAML 로더 (PyYAML 의존성 제거 — 표준 라이브러리만 사용)
# ============================================================

def _load_yaml(path: Path) -> dict:
    """PyYAML이 있으면 사용, 없으면 친절한 에러 메시지"""
    try:
        import yaml
    except ImportError:
        print("[ERROR] PyYAML 미설치. 설치 명령:")
        print("        pip install pyyaml")
        sys.exit(1)

    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f) or {}


# ============================================================
# 시크릿 매핑
# ============================================================
# brand_code 가 'serene' 일 때 다음 9~11개 파일이 자동 탐색됩니다:
#   config/serene_meta_credentials.json
#   config/serene_cafe24_token.json
#   config/serene_smartstore_credentials.json
#   config/serene_naver_credentials.json
#   config/serene_google_ads_credentials.json
#   config/serene_google_ads_token.json
#   config/serene_google_sheets_config.json
#   config/serene_google_sheets_key.json
#   config/serene_ga4_credentials.json
#   config/serene_slack_config.json
# (실제 필요 파일은 brand_config 의 enabled: true 항목에 따라 달라짐)
SECRET_FILE_MAP = {
    'meta':                 '{code}_meta_credentials.json',
    'cafe24':               '{code}_cafe24_token.json',
    'smartstore':           '{code}_smartstore_credentials.json',
    'naver_sa':             '{code}_naver_credentials.json',
    'google_ads':           '{code}_google_ads_credentials.json',
    'google_ads_token':     '{code}_google_ads_token.json',
    'google_sheets':        '{code}_google_sheets_config.json',
    'google_sheets_key':    '{code}_google_sheets_key.json',
    'google_sheets_token':  '{code}_google_sheets_token.json',  # OAuth fallback (선택)
    'ga4':                  '{code}_ga4_credentials.json',
    'slack':                '{code}_slack_config.json',
}


def _load_secret(brand_code: str, key: str) -> Optional[dict]:
    """단일 시크릿 파일 로드 (없으면 None)"""
    pattern = SECRET_FILE_MAP.get(key)
    if not pattern:
        return None
    path = SECRETS_DIR / pattern.format(code=brand_code)
    if not path.exists():
        return None
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        print(f"[WARN] 시크릿 로드 실패: {path.name} — {e}")
        return None


# ============================================================
# 객체화 (점 표기로 접근 가능)
# ============================================================

def _dict_to_ns(d):
    """중첩 dict → 점 표기 가능한 SimpleNamespace 재귀 변환"""
    if isinstance(d, dict):
        return SimpleNamespace(**{k: _dict_to_ns(v) for k, v in d.items()})
    if isinstance(d, list):
        return [_dict_to_ns(x) for x in d]
    return d


# ============================================================
# 시크릿 경로 헬퍼 (fetcher/writer 모듈에서 사용)
# ============================================================

def secret_path(brand_code: str, key: str) -> Path:
    """
    브랜드 코드 + 시크릿 키 → 절대 경로 반환.
    파일 존재 여부와 무관하게 경로만 계산.

    예:
        secret_path('renk', 'cafe24')
        → /.../config/renk_cafe24_token.json
    """
    pattern = SECRET_FILE_MAP.get(key)
    if not pattern:
        raise KeyError(f"알 수 없는 시크릿 키: {key} (가능: {list(SECRET_FILE_MAP.keys())})")
    return SECRETS_DIR / pattern.format(code=brand_code)


# ============================================================
# 메인 API
# ============================================================

def load_brand(brand_code: str, validate: bool = True) -> SimpleNamespace:
    """
    브랜드 설정 + 시크릿 통합 로드

    Args:
        brand_code: 'renk', 'serene', 'innersaeng' 등
        validate: True면 활성화된 채널의 시크릿 누락 시 에러 발생

    Returns:
        SimpleNamespace 객체.
        - brand.brand.code, brand.brand.name_kr 등
        - brand.channels.meta.enabled 등
        - brand.stores.cafe24.mall_id 등
        - brand.report.output_prefix 등
        - brand.kpi_thresholds.roas_target_pct 등
        - brand.advanced.auto_refresh_token 등
        - brand.secrets.meta (dict, 활성화된 채널만 채워짐)
        - brand.secrets.cafe24 등
    """
    # 1. brand_config yaml 로드
    yaml_path = BRAND_CONFIG_DIR / f'{brand_code}.yaml'
    if not yaml_path.exists():
        # 첫 셋업 시 안내
        template = BRAND_CONFIG_DIR / 'template.yaml.example'
        example_renk = BRAND_CONFIG_DIR / '_examples' / 'renk.yaml.example'
        print(f"[ERROR] brand_config/{brand_code}.yaml 없음.")
        print()
        print(f"신규 브랜드 셋업 방법:")
        print(f"  (권장) 코워크에서 '처음 시작' 입력 → setup-wizard 자동 안내")
        if template.exists():
            print(f"  (수동) {template.name} 을 {yaml_path.name} 로 복사 후 본인 값으로 수정")
        if example_renk.exists():
            print(f"")
            print(f"참고용 디폴트값: {example_renk.relative_to(BRAND_CONFIG_DIR.parent)}")
        sys.exit(1)

    cfg = _load_yaml(yaml_path)

    # 2. 시크릿 로드 (활성화된 매체/스토어만)
    secrets = {}
    enabled_keys = _enabled_secret_keys(cfg)

    for key in enabled_keys:
        loaded = _load_secret(brand_code, key)
        if loaded is None and validate:
            pattern = SECRET_FILE_MAP.get(key, '???')
            expected = pattern.format(code=brand_code)
            print(f"[ERROR] 활성화된 채널의 시크릿 누락: {key}")
            print(f"        기대 파일: config/{expected}")
            print(f"        해결: docs/api-guides/ 의 발급 가이드 따라 시크릿 발급 후 위 경로에 배치")
            sys.exit(1)
        secrets[key] = loaded or {}

    # 3. 통합 객체 생성
    # secrets는 dict 그대로 유지 (호진님 fetcher 코드의 creds.get(...) 인터페이스와 호환)
    secrets_dict = secrets
    ns = _dict_to_ns(cfg)
    ns.secrets = SimpleNamespace(**{k: v for k, v in secrets_dict.items()})
    # secrets 빈 여부 확인용 별도 보관 (진단 출력에서 사용)
    ns._secrets_raw = secrets_dict
    return ns


def _enabled_secret_keys(cfg: dict) -> list:
    """brand_config에서 활성화된 채널 → 필요한 시크릿 키 목록"""
    keys = []
    channels = cfg.get('channels', {})
    stores = cfg.get('stores', {})
    report = cfg.get('report', {})

    if channels.get('meta', {}).get('enabled'):
        keys.append('meta')
    if channels.get('google_ads', {}).get('enabled'):
        keys.append('google_ads')
        keys.append('google_ads_token')
    if channels.get('naver_sa', {}).get('enabled'):
        keys.append('naver_sa')
    if channels.get('ga4', {}).get('enabled'):
        keys.append('ga4')

    if stores.get('cafe24', {}).get('enabled'):
        keys.append('cafe24')
    if stores.get('smartstore', {}).get('enabled'):
        keys.append('smartstore')

    if report.get('google_sheet_id'):
        keys.append('google_sheets')
        keys.append('google_sheets_key')
    if report.get('slack_channel_id'):
        keys.append('slack')

    return keys


def list_brands() -> list:
    """brand_config/ 폴더의 사용 가능한 브랜드 코드 목록 (template/_examples 제외)"""
    if not BRAND_CONFIG_DIR.exists():
        return []
    return sorted([
        p.stem
        for p in BRAND_CONFIG_DIR.glob('*.yaml')   # 하위 디렉토리(_examples/)는 자동 제외
        if not p.name.endswith('.example')
        and p.stem != 'template'
    ])


# ============================================================
# CLI 진단
# ============================================================

def _print_brand_summary(brand):
    print(f"브랜드: {brand.brand.name_kr} ({brand.brand.name_en})")
    print(f"코드:  {brand.brand.code}")
    print()
    print("[활성 매체]")
    if brand.channels.meta.enabled:
        accounts = brand.channels.meta.accounts
        if hasattr(accounts, 'own') and accounts.own.enabled:
            print(f"  Meta 자사몰    : {accounts.own.account_id}")
        if hasattr(accounts, 'ss') and accounts.ss.enabled:
            print(f"  Meta 스마트스토어: {accounts.ss.account_id}")
    if brand.channels.google_ads.enabled:
        print(f"  Google Ads")
    if brand.channels.naver_sa.enabled:
        print(f"  네이버 검색광고")
    if hasattr(brand.channels, 'kakao_moment') and brand.channels.kakao_moment.enabled:
        print(f"  카카오 모먼트")
    if brand.channels.ga4.enabled:
        print(f"  GA4")
    print()
    print("[판매 채널]")
    if brand.stores.cafe24.enabled:
        print(f"  Cafe24 ({brand.stores.cafe24.mall_id})")
    if brand.stores.smartstore.enabled:
        print(f"  스마트스토어")
    print()
    print("[시크릿 로드 상태]")
    for k, v in brand._secrets_raw.items():
        status = "✓" if v else "✗ (비어있음)"
        print(f"  {status} {k}")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='brand_config 진단 도구')
    parser.add_argument('brand', nargs='?', help='브랜드 코드 (예: renk)')
    parser.add_argument('--list', action='store_true', help='등록된 브랜드 목록 출력')
    parser.add_argument('--no-validate', action='store_true', help='시크릿 누락 검증 건너뛰기')
    args = parser.parse_args()

    if args.list:
        brands = list_brands()
        if not brands:
            print("등록된 브랜드 없음. brand_config/{브랜드코드}.yaml 작성 후 다시 실행.")
        else:
            print("등록된 브랜드:")
            for b in brands:
                print(f"  - {b}")
        sys.exit(0)

    if not args.brand:
        parser.print_help()
        sys.exit(1)

    brand = load_brand(args.brand, validate=not args.no_validate)
    _print_brand_summary(brand)
