#!/usr/bin/env python3
"""
일간 통합 자동화 실행기 v3 (브랜드 일반화)
==================================================
brand_config 기반으로 활성 매체만 수집 → Google Sheets 아카이빙 → docx 보고서 생성.

실행 방법:
  python scripts/run_daily.py --brand renk                          # 어제 데이터
  python scripts/run_daily.py --brand renk --date 2026-04-27        # 특정 날짜
  python scripts/run_daily.py --brand renk --since 2026-04-01 --until 2026-04-27

  python scripts/run_daily.py --brand renk --slack                  # 보고서 Slack 업로드만

Windows 작업 스케줄러:
  schtasks /create /sc DAILY /tn "Brand_Daily_Report" \\
           /tr "py C:\\path\\to\\scripts\\run_daily.py --brand renk" /st 09:00

Mac/Linux crontab:
  0 9 * * * cd /path/to/repo && python scripts/run_daily.py --brand renk >> logs/daily.log 2>&1
"""

import os
import sys
import json
import argparse
import subprocess
from datetime import datetime, timedelta
from pathlib import Path

# scripts/ 디렉터리를 path에 추가 (utils, fetchers 등 import 가능)
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent
sys.path.insert(0, str(SCRIPT_DIR))

from utils.config_loader import load_brand
from utils.active_brand import set_active
from utils.logger import log, section


# ============================================================
# 폴더 경로
# ============================================================

LOG_DIR = ROOT_DIR / 'logs'
REPORT_DIR = ROOT_DIR / 'reports'
DATA_DIR = ROOT_DIR / 'data'


def ensure_dirs():
    for d in (LOG_DIR, REPORT_DIR, DATA_DIR):
        d.mkdir(exist_ok=True)


# ============================================================
# 매체별 수집 (brand_config 기반 분기)
# ============================================================

def collect_meta(brand, since, until):
    """Meta API 수집 — 자사몰/스마트스토어 광고계정 분리 운영 지원"""
    if not brand.channels.meta.enabled:
        log("  Meta: 비활성 — 건너뜀", 'INFO')
        return {}, {}, {}, {}

    try:
        from fetchers.meta_fetcher import (
            fetch_account_insights, fetch_campaign_insights, save_to_csv
        )
    except ImportError as e:
        log(f"Meta 모듈 임포트 실패: {e}", 'WARN')
        return {}, {}, {}, {}

    prev_date = (datetime.strptime(since, '%Y-%m-%d') - timedelta(days=1)).strftime('%Y-%m-%d')
    own_data, ss_data, own_camp, ss_camp = {}, {}, {}, {}
    accounts = brand.channels.meta.accounts

    log("  Meta API: 계정 데이터 수집 중...")
    if hasattr(accounts, 'ss') and accounts.ss.enabled:
        ss_data = fetch_account_insights(accounts.ss.account_id, prev_date, until, '스마트스토어')
    if hasattr(accounts, 'own') and accounts.own.enabled:
        own_data = fetch_account_insights(accounts.own.account_id, prev_date, until, '자사몰')

    log("  Meta API: 캠페인 데이터 수집 중...")
    if hasattr(accounts, 'own') and accounts.own.enabled:
        own_camp = fetch_campaign_insights(accounts.own.account_id, since, until, '자사몰 캠페인')
    if hasattr(accounts, 'ss') and accounts.ss.enabled:
        ss_camp = fetch_campaign_insights(accounts.ss.account_id, since, until, '스마트스토어 캠페인')

    # 백업 CSV 저장
    ts = datetime.now().strftime('%Y%m%d_%H%M')
    if ss_data:
        save_to_csv(ss_data, f"meta_ss_{ts}.csv")
    if own_data:
        save_to_csv(own_data, f"meta_own_{ts}.csv")

    return own_data or {}, ss_data or {}, own_camp or {}, ss_camp or {}


def collect_cafe24(brand, since, until):
    """카페24 자사몰 매출 수집"""
    if not brand.stores.cafe24.enabled:
        return {}

    try:
        from fetchers.cafe24_fetcher import fetch_daily_data as cafe24_fetch
    except ImportError:
        log("  카페24 모듈 미설치 — 자사몰 커머스 수치 수동 입력 필요", 'WARN')
        return {}

    log("  카페24 API: 자사몰 매출 수집 중...")
    cafe24_data = {}
    current = datetime.strptime(since, '%Y-%m-%d')
    end = datetime.strptime(until, '%Y-%m-%d')
    prev = current - timedelta(days=1)

    for d in [prev] + [current + timedelta(days=i) for i in range((end - current).days + 1)]:
        d_str = d.strftime('%Y-%m-%d')
        try:
            result = cafe24_fetch(d_str)
            if result and result.get('order_count', 0) > 0:
                cafe24_data[d_str] = result
        except Exception as e:
            log(f"  카페24 {d_str} 실패: {e}", 'WARN')

    if cafe24_data:
        log(f"  카페24 {len(cafe24_data)}일 데이터 수집 완료")
    return cafe24_data


def collect_cafe24_top_products(brand, date_str):
    """카페24 상품 판매 TOP N 수집"""
    if not brand.stores.cafe24.enabled:
        return []
    try:
        from fetchers.cafe24_top_products import fetch_top_products
    except ImportError:
        log("  카페24 상품TOP 모듈 미설치", 'WARN')
        return []

    top_n = brand.report.cafe24_top_products_count
    log(f"  카페24 상품 TOP {top_n} 수집 중 ({date_str})...")
    try:
        topn = fetch_top_products(date_str, top_n=top_n)
        if topn:
            for i, p in enumerate(topn):
                log(f"    #{i+1} {p['product_name'][:30]} — {p['amount']:,}원 ({p['quantity']}개)")
        return topn
    except Exception as e:
        log(f"  카페24 상품TOP 수집 실패: {e}", 'WARN')
        return []


def collect_naver(brand, since, until):
    """네이버 검색광고 데이터 수집"""
    if not brand.channels.naver_sa.enabled:
        return {}

    try:
        from fetchers.naver_sa_fetcher import fetch_naver_data
    except ImportError:
        log("  네이버 모듈 미설치 — 네이버 SA/BS/쇼검 수동 입력 필요", 'WARN')
        return {}

    log("  네이버 검색광고 API: 데이터 수집 중...")
    try:
        prev_date = (datetime.strptime(since, '%Y-%m-%d') - timedelta(days=1)).strftime('%Y-%m-%d')
        return fetch_naver_data(prev_date, until)
    except Exception as e:
        log(f"  네이버 수집 실패: {e}", 'WARN')
        return {}


def collect_google_ads(brand, since, until):
    """Google Ads 데이터 수집"""
    if not brand.channels.google_ads.enabled:
        return {}

    try:
        from fetchers.google_ads_fetcher import fetch_google_data
    except ImportError:
        log("  Google Ads 모듈 미설치 — Google 수동 입력 필요", 'WARN')
        return {}

    log("  Google Ads API: 데이터 수집 중...")
    try:
        prev_date = (datetime.strptime(since, '%Y-%m-%d') - timedelta(days=1)).strftime('%Y-%m-%d')
        return fetch_google_data(prev_date, until)
    except Exception as e:
        log(f"  Google Ads 수집 실패: {e}", 'WARN')
        return {}


def collect_smartstore(brand, since, until):
    """네이버 스마트스토어 커머스 데이터 수집"""
    if not brand.stores.smartstore.enabled:
        return {}
    try:
        from fetchers.smartstore_fetcher import fetch_smartstore_data
    except ImportError:
        log("  스마트스토어 모듈 미설치 — 스마트스토어 커머스 수동 입력 필요", 'WARN')
        return {}

    log("  스마트스토어 커머스 API: 매출 데이터 수집 중...")
    try:
        prev_date = (datetime.strptime(since, '%Y-%m-%d') - timedelta(days=1)).strftime('%Y-%m-%d')
        return fetch_smartstore_data(prev_date, until)
    except Exception as e:
        log(f"  스마트스토어 수집 실패: {e}", 'WARN')
        return {}


def collect_ga4(brand, since, until):
    """GA4 웹 트래픽 데이터 수집"""
    if not brand.channels.ga4.enabled:
        return {}
    try:
        from fetchers.ga4_fetcher import fetch_ga4_data
    except ImportError:
        log("  GA4 모듈 미설치 — GA4 데이터 수동 확인 필요", 'WARN')
        return {}

    log("  GA4 Data API: 웹 트래픽 데이터 수집 중...")
    try:
        prev_date = (datetime.strptime(since, '%Y-%m-%d') - timedelta(days=1)).strftime('%Y-%m-%d')
        return fetch_ga4_data(prev_date, until)
    except Exception as e:
        log(f"  GA4 수집 실패: {e}", 'WARN')
        return {}


# ============================================================
# Google Sheets 아카이빙
# ============================================================

def archive_to_sheets(brand, date_str, own, ss, naver_data, google_data, cafe24,
                       top_products=None, smartstore=None):
    """Google Sheets 일별 데이터 기입 (매체별 시트 분리)"""
    if not brand.report.google_sheet_id:
        log("  google_sheet_id 미설정 — 시트 아카이빙 건너뜀", 'INFO')
        return False
    try:
        from writers.google_sheets_writer import append_daily_data
    except ImportError:
        log("  Google Sheets 모듈 미설치 — 아카이빙 건너뜀", 'WARN')
        return False

    try:
        nv = naver_data.get(date_str, {})
        ggl = google_data.get(date_str, {})
        result = append_daily_data(date_str, own, ss, nv, ggl, cafe24, top_products, smartstore)
        if result:
            log(f"  Google Sheets 기입 완료: {date_str}")
        return result
    except Exception as e:
        log(f"  Google Sheets 기입 실패: {e}", 'WARN')
        return False


# ============================================================
# docx 보고서 생성 (Node.js generate_daily_report.js 호출)
# ============================================================

def generate_docx_report(brand, date_str, own, ss, own_campaigns, ss_campaigns,
                          prev_own, prev_ss, cafe24, prev_cafe24,
                          naver_data, google_data, top_products=None,
                          ga4_data=None, smartstore=None, prev_smartstore=None):
    """Node.js generate_daily_report.js 호출 → docx 생성"""
    prev_date = (datetime.strptime(date_str, '%Y-%m-%d') - timedelta(days=1)).strftime('%Y-%m-%d')

    # BS 월정액 (네이버 브랜드검색)
    bs_monthly = 0
    naver_cfg = getattr(brand.channels, 'naver_sa', None)
    if naver_cfg and hasattr(naver_cfg, 'bs_monthly_cost'):
        bs_monthly = int(naver_cfg.bs_monthly_cost)

    report_data = {
        'brand': {
            'code': brand.brand.code,
            'name_kr': brand.brand.name_kr,
            'name_en': brand.brand.name_en,
            'output_prefix': brand.report.output_prefix,
        },
        'bs_monthly_cost': bs_monthly,
        'date': date_str,
        'own': own,
        'ss': ss,
        'own_campaigns': own_campaigns,
        'ss_campaigns': ss_campaigns,
        'prev_own': prev_own,
        'prev_ss': prev_ss,
        'cafe24': cafe24,
        'prev_cafe24': prev_cafe24,
        'naver': naver_data.get(date_str, {}),
        'prev_naver': naver_data.get(prev_date, {}),
        'google': google_data.get(date_str, {}),
        'prev_google': google_data.get(prev_date, {}),
        'top_products': top_products or [],
        'ga4': (ga4_data or {}).get(date_str, {}),
        'prev_ga4': (ga4_data or {}).get(prev_date, {}),
        'smartstore_commerce': smartstore or {},
        'prev_smartstore_commerce': prev_smartstore or {},
    }

    data_path = DATA_DIR / f"report_data_{date_str}.json"
    with open(data_path, 'w', encoding='utf-8') as f:
        json.dump(report_data, f, ensure_ascii=False, indent=2, default=str)

    dt = datetime.strptime(date_str, '%Y-%m-%d')
    weekdays = ['월', '화', '수', '목', '금', '토', '일']
    wd = weekdays[dt.weekday()]
    output_name = f"{brand.report.output_prefix}_Daily_Report_{date_str}({wd}).docx"
    output_path = REPORT_DIR / output_name

    generator_path = SCRIPT_DIR / 'writers' / 'generate_daily_report.js'
    if not generator_path.exists():
        log(f"docx 생성기 없음: {generator_path}", 'ERROR')
        return None

    # 파일 잠금 방지: 기존 파일이 열려 있으면 대체 파일명 사용
    final_output = output_path
    if output_path.exists():
        try:
            with open(output_path, 'a'):
                pass
        except (PermissionError, OSError):
            ts = datetime.now().strftime('%H%M%S')
            alt_name = f"{brand.report.output_prefix}_Daily_Report_{date_str}({wd})_{ts}.docx"
            final_output = REPORT_DIR / alt_name
            log(f"  기존 파일 잠김 → 대체 파일명: {alt_name}", 'WARN')

    try:
        result = subprocess.run(
            ['node', str(generator_path), str(data_path), str(final_output)],
            capture_output=True, timeout=60,
            cwd=str(ROOT_DIR),
            encoding='utf-8', errors='replace',
        )
        if result.returncode == 0:
            log(f"  docx 보고서 생성 완료: {final_output.name}")
            return str(final_output)
        else:
            log(f"  docx 생성 실패: {result.stderr}", 'ERROR')
            return None
    except FileNotFoundError:
        log("  Node.js 미설치 — docx 보고서 생성 불가. NodeJS_설치가이드.md 참고.", 'ERROR')
        return None
    except subprocess.TimeoutExpired:
        log("  docx 생성 타임아웃", 'ERROR')
        return None


# ============================================================
# Slack 업로드 (--slack 모드)
# ============================================================

def post_to_slack(brand, date_str):
    """이미 생성된 docx 보고서를 Slack에 업로드"""
    try:
        from publishers.slack_uploader import find_report, load_config, upload_file_to_channel
    except ImportError:
        log("  slack_uploader 모듈 없음 — Slack 발행 건너뜀", 'WARN')
        return False

    config = load_config()
    if not config:
        return False

    token = config.get('user_token') or config.get('bot_token')
    channel = config.get('channel_id') or brand.report.slack_channel_id
    if not token or not channel:
        log("  Slack 토큰 또는 채널 미설정", 'WARN')
        return False

    report_path = find_report(date_str)
    if not report_path:
        log(f"  {date_str} 보고서 파일 없음 (reports/ 폴더 확인)", 'ERROR')
        return False

    log(f"  Slack 파일 업로드: {os.path.basename(report_path)}")
    return upload_file_to_channel(report_path, channel, token)


# ============================================================
# 메인 파이프라인
# ============================================================

def run_pipeline(brand, since: str, until: str):
    """전체 파이프라인 실행"""
    section(f"{brand.brand.name_kr} ({brand.brand.name_en}) Daily 자동화 시작 ({since} ~ {until})")

    # ── Step 1: 전체 매체 데이터 수집 ──
    log("Step 1: 전체 매체 데이터 수집")

    own_data, ss_data, own_campaigns, ss_campaigns = collect_meta(brand, since, until)
    cafe24_data = collect_cafe24(brand, since, until)
    smartstore_data = collect_smartstore(brand, since, until)
    naver_data = collect_naver(brand, since, until)
    google_data = collect_google_ads(brand, since, until)
    ga4_data = collect_ga4(brand, since, until)

    # ── Step 2: 시트 아카이빙 + docx 생성 ──
    log("Step 2: Google Sheets 아카이빙 + docx 보고서 생성")

    current = datetime.strptime(since, '%Y-%m-%d')
    end = datetime.strptime(until, '%Y-%m-%d')
    prev_d_func = lambda d: (datetime.strptime(d, '%Y-%m-%d') - timedelta(days=1)).strftime('%Y-%m-%d')

    while current <= end:
        d = current.strftime('%Y-%m-%d')
        prev_d = prev_d_func(d)

        own = own_data.get(d, {})
        ss = ss_data.get(d, {})
        prev_own = own_data.get(prev_d, {})
        prev_ss = ss_data.get(prev_d, {})
        c24 = cafe24_data.get(d, {})
        prev_c24 = cafe24_data.get(prev_d, {})
        own_camp = own_campaigns.get(d, [])
        ss_camp = ss_campaigns.get(d, [])
        sst = smartstore_data.get(d, {})
        prev_sst = smartstore_data.get(prev_d, {})

        # 카페24 상품 TOP
        top_products = collect_cafe24_top_products(brand, d) if c24.get('order_count', 0) > 0 else []

        # 시트 아카이빙
        archive_to_sheets(brand, d, own, ss, naver_data, google_data, c24, top_products, sst)

        # docx 보고서
        generate_docx_report(
            brand, d, own, ss, own_camp, ss_camp,
            prev_own, prev_ss, c24, prev_c24,
            naver_data, google_data, top_products,
            ga4_data, sst, prev_sst,
        )

        current += timedelta(days=1)

    # ── Step 3: 결과 요약 ──
    section("결과 요약")
    _print_summary(brand, since, until, own_data, ss_data, naver_data,
                    google_data, cafe24_data, smartstore_data, ga4_data)

    section("파이프라인 완료")
    log(f"  보고서 폴더: {REPORT_DIR}")


def _print_summary(brand, since, until, own_data, ss_data, naver_data,
                    google_data, cafe24_data, smartstore_data, ga4_data):
    """결과 요약 출력"""
    current = datetime.strptime(since, '%Y-%m-%d')
    end = datetime.strptime(until, '%Y-%m-%d')

    while current <= end:
        d = current.strftime('%Y-%m-%d')
        own = own_data.get(d, {})
        ss = ss_data.get(d, {})
        nv = naver_data.get(d, {})
        ggl = google_data.get(d, {})
        c24 = cafe24_data.get(d, {})
        sst = smartstore_data.get(d, {})
        ga4 = ga4_data.get(d, {})

        log(f"  {d}:")
        if brand.channels.meta.enabled:
            own_cost = own.get('cost', 0)
            own_rev = own.get('revenue', 0)
            own_roas = int(own_rev / own_cost * 100) if own_cost > 0 else 0
            ss_cost = ss.get('cost', 0)
            ss_cpas = ss.get('cpas_revenue', 0)
            ss_roas = int(ss_cpas / ss_cost * 100) if ss_cost > 0 else 0
            log(f"    META 자사몰     광고비 {int(own_cost):,}원 | 매출 {int(own_rev):,}원 | ROAS {own_roas}%")
            log(f"    META 스마트스토어 광고비 {int(ss_cost):,}원 | CPAS 전환값 {int(ss_cpas):,}원 | ROAS {ss_roas}%")
        if nv:
            nv_sa = nv.get('sa', {})
            log(f"    네이버 SA      광고비 {nv_sa.get('cost', 0):,}원 | 클릭 {nv_sa.get('clicks', 0)}")
        if ggl:
            ggl_t = ggl.get('total', {})
            log(f"    Google Ads     광고비 {ggl_t.get('cost', 0):,}원 | 클릭 {ggl_t.get('clicks', 0)}")
        if c24 and c24.get('order_count', 0) > 0:
            log(f"    카페24 자사몰   결제합계 {c24['paid_amount']:,}원 | 환불 {c24.get('refund_amount',0):,}원 | 순매출 {c24.get('net_sales',0):,}원 | 주문 {c24['order_count']}건")
        if sst and sst.get('order_count', 0) > 0:
            log(f"    스마트스토어    결제합계 {sst.get('paid_amount',0):,}원 | 환불 {sst.get('refund_amount',0):,}원 | 순매출 {sst.get('net_revenue',0):,}원 | 주문 {sst['order_count']}건")
        if ga4 and ga4.get('overview'):
            ov = ga4['overview']
            log(f"    GA4            세션 {ov.get('sessions', 0):,} | 사용자 {ov.get('users', 0):,} | 신규 {ov.get('new_users', 0):,} | 구매 {ov.get('purchases', 0)}건 | 이탈률 {ov.get('bounce_rate', 0)*100:.1f}%")

        total_cost = int(
            (own.get('cost', 0) if brand.channels.meta.enabled else 0)
            + (ss.get('cost', 0) if brand.channels.meta.enabled else 0)
            + nv.get('sa', {}).get('cost', 0)
            + ggl.get('total', {}).get('cost', 0)
        )
        log(f"    ─ 전체 매체 합산 광고비: {total_cost:,}원")

        current += timedelta(days=1)


# ============================================================
# CLI
# ============================================================

def main():
    parser = argparse.ArgumentParser(description='일간 통합 자동화 v3 (브랜드 일반화)')
    parser.add_argument('--brand', required=True, help='브랜드 코드 (예: renk)')
    parser.add_argument('--date', help='처리 날짜 (YYYY-MM-DD)')
    parser.add_argument('--since', help='시작일 (YYYY-MM-DD)')
    parser.add_argument('--until', help='종료일 (YYYY-MM-DD)')
    parser.add_argument('--slack', action='store_true', help='Slack 보고서 발행만 (수집/생성 건너뜀)')
    parser.add_argument('--dump-raw', action='store_true',
                        help='검증·디버깅용: 모든 fetcher 의 가공 결과를 data/raw/{date}/ 에 JSON 저장')
    args = parser.parse_args()

    # 1. brand_config 로드 + active_brand 설정 (모든 fetcher/writer 가 참조)
    brand = load_brand(args.brand)
    set_active(brand)

    # 1-b. raw dump 활성화 (선택)
    if args.dump_raw:
        from utils.raw_dumper import enable_dump, get_raw_dir
        enable_dump()
        log(f"Raw dump 활성화 → {get_raw_dir()}", 'INFO')

    # 2. 날짜 결정
    if args.date:
        since = until = args.date
    elif args.since and args.until:
        since, until = args.since, args.until
    else:
        yesterday = datetime.now() - timedelta(days=1)
        since = until = yesterday.strftime('%Y-%m-%d')

    ensure_dirs()

    # 3. --slack 모드: 보고서 파일 찾아서 Slack 발행만 실행
    if args.slack:
        ok = post_to_slack(brand, since)
        sys.exit(0 if ok else 1)

    # 4. 정상 파이프라인
    try:
        run_pipeline(brand, since, until)
    except KeyboardInterrupt:
        log("사용자 중단", 'WARN')
        sys.exit(0)
    except Exception as e:
        log(f"오류: {e}", 'ERROR')
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
