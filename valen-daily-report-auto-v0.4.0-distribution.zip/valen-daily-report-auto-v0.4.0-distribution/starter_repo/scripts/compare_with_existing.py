#!/usr/bin/env python3
"""
기존 환경 vs starter v1.0 산출물 자동 비교 도구
================================================
Phase 1 검증용. 같은 날짜의 두 환경 산출물을 받아 셀 단위 diff.

비교 대상 (4종):
  1) starter 의 raw dump (data/raw/{date}/*.json)
  2) starter 의 docx 보고서 (reports/*.docx)
  3) starter 의 Google Sheets 행 (실시간 조회)
  4) 호진님 기존 환경의 docx 보고서 (--existing-docx 인자)

사용법:
  # 기본 — starter raw dump + docx 만 자체 검증
  python scripts/compare_with_existing.py --brand renk --date 2026-04-29

  # + 호진님 기존 환경 docx 와 비교
  python scripts/compare_with_existing.py --brand renk --date 2026-04-29 \\
    --existing-docx /path/to/existing/ReNK_Daily_Report_2026-04-29(수).docx
"""

import os
import sys
import json
import argparse
import zipfile
import re
from pathlib import Path
from datetime import datetime
from xml.etree import ElementTree as ET

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = SCRIPT_DIR.parent
sys.path.insert(0, str(SCRIPT_DIR))

# 색상 (Windows cmd 미지원 시 빈 문자열로)
class Color:
    RED    = '\033[91m'
    GREEN  = '\033[92m'
    YELLOW = '\033[93m'
    GRAY   = '\033[90m'
    BOLD   = '\033[1m'
    END    = '\033[0m'

if os.name == 'nt' and not os.environ.get('FORCE_COLOR'):
    for k in dir(Color):
        if not k.startswith('_'):
            setattr(Color, k, '')

C = Color


# ============================================================
# 1) docx → 표 + 텍스트 추출 (수치 비교용)
# ============================================================

def extract_docx_text_and_numbers(docx_path: Path) -> dict:
    """
    docx 파일에서 모든 텍스트 + 표 셀 텍스트 추출.
    리턴: {
      'paragraphs': [str, ...],
      'tables': [[[cell_text, ...], ...], ...],
      'numbers': [(context, number_str), ...]    # 모든 수치 (콤마 처리)
    }
    """
    if not docx_path.exists():
        raise FileNotFoundError(f"docx 파일 없음: {docx_path}")

    namespaces = {
        'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    }

    paragraphs = []
    tables = []
    numbers = []

    with zipfile.ZipFile(str(docx_path), 'r') as z:
        with z.open('word/document.xml') as f:
            tree = ET.parse(f)

    root = tree.getroot()
    body = root.find('w:body', namespaces)
    if body is None:
        return {'paragraphs': [], 'tables': [], 'numbers': []}

    def get_text(elem):
        """w:t 요소 모두 모아서 텍스트로"""
        return ''.join(t.text or '' for t in elem.findall('.//w:t', namespaces))

    NUM_PATTERN = re.compile(r'-?[\d,]+\.?\d*%?원?')

    for child in body:
        tag = child.tag.split('}')[-1]
        if tag == 'p':
            text = get_text(child)
            if text.strip():
                paragraphs.append(text)
                # 수치 추출
                for m in NUM_PATTERN.findall(text):
                    if any(c.isdigit() for c in m):
                        numbers.append((text[:50], m))
        elif tag == 'tbl':
            rows = []
            for tr in child.findall('w:tr', namespaces):
                row = []
                for tc in tr.findall('w:tc', namespaces):
                    cell_text = get_text(tc)
                    row.append(cell_text)
                    # 수치 추출
                    for m in NUM_PATTERN.findall(cell_text):
                        if any(c.isdigit() for c in m):
                            numbers.append((cell_text[:50], m))
                rows.append(row)
            tables.append(rows)

    return {
        'paragraphs': paragraphs,
        'tables': tables,
        'numbers': numbers,
    }


# ============================================================
# 2) 두 docx 산출물 비교 (1:1 셀 단위)
# ============================================================

def normalize_number(s: str) -> str:
    """비교를 위한 수치 정규화: 콤마, 단위 제거"""
    if not s:
        return ''
    return s.replace(',', '').replace('원', '').strip()


def compare_docx(existing_path: Path, starter_path: Path) -> dict:
    """두 docx 의 표 셀 + 단락 텍스트 1:1 비교"""
    print(f"\n{C.BOLD}── docx 1:1 비교 ──{C.END}")
    print(f"  기존:  {existing_path.name}")
    print(f"  starter: {starter_path.name}")

    e = extract_docx_text_and_numbers(existing_path)
    s = extract_docx_text_and_numbers(starter_path)

    diffs = []

    # 표 비교
    e_tables = e['tables']
    s_tables = s['tables']

    if len(e_tables) != len(s_tables):
        diffs.append(f"표 개수 차이: 기존 {len(e_tables)}개 / starter {len(s_tables)}개")

    table_count = min(len(e_tables), len(s_tables))
    for ti in range(table_count):
        et = e_tables[ti]
        st = s_tables[ti]
        if len(et) != len(st):
            diffs.append(f"표 #{ti+1} 행 수 차이: 기존 {len(et)} / starter {len(st)}")
            continue
        for ri, (er, sr) in enumerate(zip(et, st)):
            if len(er) != len(sr):
                diffs.append(f"표 #{ti+1} 행 {ri+1} 컬럼 수 차이")
                continue
            for ci, (ec, sc) in enumerate(zip(er, sr)):
                ec_norm = normalize_number(ec)
                sc_norm = normalize_number(sc)
                if ec.strip() != sc.strip() and ec_norm != sc_norm:
                    # 헤더(첫 행)는 텍스트 차이 무시 가능
                    if ri == 0:
                        continue
                    diffs.append(
                        f"표 #{ti+1} [{ri+1},{ci+1}] '{ec[:30]}' ≠ '{sc[:30]}'"
                    )

    # 단락 수치 비교 (전체 단락의 모든 수치를 set으로)
    e_numbers = set(normalize_number(n) for _, n in e['numbers'])
    s_numbers = set(normalize_number(n) for _, n in s['numbers'])
    only_in_existing = e_numbers - s_numbers
    only_in_starter  = s_numbers - e_numbers

    if only_in_existing:
        diffs.append(f"기존 docx 에만 있는 수치 {len(only_in_existing)}개: {sorted(only_in_existing)[:10]}")
    if only_in_starter:
        diffs.append(f"starter docx 에만 있는 수치 {len(only_in_starter)}개: {sorted(only_in_starter)[:10]}")

    # 결과 출력
    if not diffs:
        print(f"  {C.GREEN}✓ 모든 표·수치 일치{C.END}")
        return {'pass': True, 'diffs': []}
    else:
        print(f"  {C.RED}✗ {len(diffs)}건 차이 발견{C.END}")
        for d in diffs[:30]:
            print(f"    {C.YELLOW}- {d}{C.END}")
        if len(diffs) > 30:
            print(f"    {C.GRAY}... 외 {len(diffs)-30}건{C.END}")
        return {'pass': False, 'diffs': diffs}


# ============================================================
# 3) starter raw dump 검사 (모든 매체 데이터가 정상 수집됐는지)
# ============================================================

def check_starter_raw(date_str: str) -> dict:
    """starter 의 data/raw/{date}/ 폴더 내용 점검"""
    print(f"\n{C.BOLD}── starter raw dump 점검 ──{C.END}")
    raw_dir = ROOT / 'data' / 'raw' / date_str

    if not raw_dir.exists():
        print(f"  {C.RED}✗ raw dump 폴더 없음: {raw_dir}{C.END}")
        print(f"  {C.GRAY}  → run_daily.py --dump-raw 옵션으로 실행했는지 확인{C.END}")
        return {'pass': False, 'diffs': [f"raw dir 없음: {raw_dir}"]}

    files = sorted(raw_dir.glob('*.json'))
    if not files:
        print(f"  {C.RED}✗ raw 파일 없음{C.END}")
        return {'pass': False, 'diffs': ["raw 파일 0개"]}

    print(f"  {C.GREEN}✓ {len(files)}개 파일 발견{C.END}")

    # 매체별 분류
    by_channel = {}
    for f in files:
        # 파일명: {channel}_{id}_{ts}.json
        prefix = f.name.split('_')[0]
        by_channel.setdefault(prefix, []).append(f)

    expected = ['meta', 'cafe24', 'naver', 'google', 'ga4', 'smartstore']
    missing = []
    for ch in expected:
        found = any(ch in k for k in by_channel.keys())
        if found:
            count = sum(len(v) for k, v in by_channel.items() if ch in k)
            print(f"    {C.GREEN}✓{C.END} {ch}: {count}개 파일")
        else:
            print(f"    {C.YELLOW}-{C.END} {ch}: 파일 없음 (해당 매체 비활성이면 정상)")

    return {'pass': True, 'diffs': [], 'files_count': len(files)}


# ============================================================
# 메인
# ============================================================

def main():
    parser = argparse.ArgumentParser(description='기존 환경 ↔ starter 산출물 비교')
    parser.add_argument('--brand', required=True, help='브랜드 코드')
    parser.add_argument('--date', required=True, help='비교 날짜 (YYYY-MM-DD)')
    parser.add_argument('--existing-docx', help='호진님 기존 환경의 docx 경로')
    parser.add_argument('--starter-docx', help='starter 의 docx 경로 (자동 탐색 가능)')
    args = parser.parse_args()

    print(f"{C.BOLD}{'='*60}{C.END}")
    print(f"{C.BOLD}  검증 보고: {args.brand} / {args.date}{C.END}")
    print(f"{C.BOLD}{'='*60}{C.END}")

    summary = {}

    # 1. starter raw dump 점검
    summary['raw'] = check_starter_raw(args.date)

    # 2. starter docx 자동 탐색
    starter_docx = None
    if args.starter_docx:
        starter_docx = Path(args.starter_docx)
    else:
        reports_dir = ROOT / 'reports'
        if reports_dir.exists():
            candidates = list(reports_dir.glob(f"*Daily_Report_{args.date}*.docx"))
            if candidates:
                starter_docx = candidates[0]
                print(f"\n{C.GRAY}  [auto] starter docx: {starter_docx.name}{C.END}")

    # 3. docx 1:1 비교 (기존 환경 docx 가 주어진 경우)
    if args.existing_docx and starter_docx:
        existing = Path(args.existing_docx)
        if not existing.exists():
            print(f"{C.RED}  ✗ 기존 docx 없음: {existing}{C.END}")
        elif not starter_docx.exists():
            print(f"{C.RED}  ✗ starter docx 없음: {starter_docx}{C.END}")
        else:
            summary['docx'] = compare_docx(existing, starter_docx)
    elif not args.existing_docx:
        print(f"\n{C.GRAY}  [skip] 기존 docx 미지정 (--existing-docx 옵션) → docx 비교 건너뜀{C.END}")

    # 최종 요약
    print(f"\n{C.BOLD}{'='*60}{C.END}")
    print(f"{C.BOLD}  최종 결과{C.END}")
    print(f"{C.BOLD}{'='*60}{C.END}")
    all_pass = True
    for category, result in summary.items():
        if result.get('pass'):
            print(f"  {C.GREEN}✓ {category}{C.END}")
        else:
            print(f"  {C.RED}✗ {category} ({len(result.get('diffs', []))}건){C.END}")
            all_pass = False

    if all_pass:
        print(f"\n{C.BOLD}{C.GREEN}  통과 — 다음 단계 진행 가능{C.END}")
        sys.exit(0)
    else:
        print(f"\n{C.BOLD}{C.RED}  미통과 — 차이 분석 후 재검증 필요{C.END}")
        sys.exit(1)


if __name__ == '__main__':
    main()
