@echo off
REM ============================================================
REM Slack 단독 발행 (보고서는 이미 생성된 상태에서)
REM ============================================================
REM 사용법:
REM   slack.bat                       어제자 리포트 Slack 발행
REM   slack.bat 2026-04-27            특정 날짜
REM   slack.bat 2026-04-27 renk       특정 날짜 + 브랜드 지정
REM ============================================================

cd /d "%~dp0"

set "DATE_ARG=%~1"
set "BRAND_ARG=%~2"

if "%BRAND_ARG%"=="" (
    if exist .env (
        for /f "tokens=2 delims==" %%a in ('findstr /b "DEFAULT_BRAND=" .env') do set "BRAND_ARG=%%a"
    )
)
if "%BRAND_ARG%"=="" (
    for %%f in (brand_config\*.yaml) do (
        if /i not "%%~xf"==".example" (
            set "BRAND_ARG=%%~nf"
            goto :brand_set
        )
    )
)
:brand_set

if "%DATE_ARG%"=="" (
    py scripts\run_daily.py --brand %BRAND_ARG% --slack
) else (
    py scripts\run_daily.py --brand %BRAND_ARG% --date %DATE_ARG% --slack
)

pause
