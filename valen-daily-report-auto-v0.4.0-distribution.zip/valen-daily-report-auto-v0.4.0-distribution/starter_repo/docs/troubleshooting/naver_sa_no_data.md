# 네이버 검색광고 API 오류

## 증상 1: 데이터 없음 (cost=0, clicks=0)

```
2026-04-27: 광고비 0원 | 클릭 0 | 구매전환 0건
```

## 원인

- 해당 날짜에 광고 집행 안 됨 (정상)
- customer_id 가 본인 광고주 ID 가 아님
- API 권한 없음

## 해결

### customer_id 확인

네이버 검색광고 관리시스템 로그인 → 우측 상단 본인 정보 → "광고주 ID" 9자리 숫자.

`config/{브랜드}_naver_credentials.json`:
```json
{
  "search_ad": {
    "customer_id": "1234567",
    "api_key":     "...",
    "secret_key":  "..."
  }
}
```

### API 권한 발급

네이버 검색광고센터 → 도구 → API 사용 관리 → "API 사용 신청" → 본인 광고주에 권한 부여.

## 증상 2: 401 Unauthorized

```
[ERROR] 네이버 SA API (HTTP 401): Invalid signature
```

## 원인

전자서명 생성 실패. 보통 다음 중 하나:
- API Key 또는 Secret Key 오타
- 시스템 시간이 네이버 서버와 너무 차이남 (3분 이상)

## 해결

1. `config/{브랜드}_naver_credentials.json` 의 `api_key`, `secret_key` 재확인 (앞뒤 공백 주의)
2. PC 시간을 인터넷 시간과 동기화
   - Windows: 설정 → 시간 및 언어 → "지금 동기화"
   - Mac: 시스템 환경설정 → 날짜 및 시간 → "자동으로 시간 설정"

## 증상 3: 브랜드검색(BS) 광고비 0원

```
2026-04-27: 브랜드검색: 0원 | 클릭 61
```

## 원인 / 동작

브랜드검색은 **월 정액 계약**이라 일별 광고비가 API 에서 0원으로 반환됨. 정상 동작.

## 해결 (이미 적용됨)

`brand_config/{브랜드}.yaml` 에 월정액 입력 시 자동으로 일할 환산:

```yaml
channels:
  naver_sa:
    enabled: true
    bs_monthly_cost: 2530000     # ← 월 253만원 → 일별 약 84,333원으로 자동 환산
```

`bs_monthly_cost: 0` 또는 미입력 시 일할 환산 안 함 (브랜드검색 미사용 브랜드).

## 증상 4: 쇼핑검색 광고가 분리 안 됨

```
파워링크: 80,260원 | 클릭 72
쇼핑검색: 0원 | 클릭 0          ← 빈 값
```

## 원인

쇼핑검색 광고가 별도 캠페인이 아니라 파워링크 캠페인 안에 통합됨.

## 해결

스크립트는 `WEB_SITE` (파워링크), `SHOPPING` (쇼핑검색), `BRAND_SEARCH` (브랜드검색) 캠페인 타입으로 자동 분류. 본인 광고에서 캠페인 타입을 잘못 설정한 경우 이 분류가 어긋남.

→ 네이버 검색광고센터에서 캠페인 타입 확인 + 재설정.

## 관련 코드

- `scripts/fetchers/naver_sa_fetcher.py` - `CAMPAIGN_TYPE_MAP`, `fetch_naver_data()`
