# Meta API 한도 / 토큰 오류

## 증상 1: 액세스 토큰 만료

```
[오류] 액세스 토큰이 만료되었습니다 (code: 190)
  → docs/api-guides/META_API_셋업가이드.html 참고하여 토큰 재발급 후
     config/{브랜드}_meta_credentials.json 의 access_token 업데이트하세요.
```

## 원인

- 일반 사용자 토큰: 60일 만료
- 시스템 사용자 토큰: 무기한이지만 권한 변경/계정 비활성화 시 폐기

## 해결

### 시스템 사용자 토큰 재발급 (권장)

1. https://business.facebook.com/settings/system-users
2. 본인 시스템 사용자 선택 → "새 토큰 생성"
3. **자산 선택**: 본인 브랜드 광고계정
4. **권한**: `ads_read` (필수), `ads_management` (선택)
5. **만료**: 만료 없음
6. 생성된 토큰을 `config/{브랜드}_meta_credentials.json` 의 `access_token` 에 입력

```json
{
  "access_token": "EAAm..."
}
```

> ⚠️ 토큰 재발급 시 기존 토큰은 자동 폐기되지 않습니다. 보안상 만료시키려면 별도로 "토큰 디버거"에서 invalidate 진행.

## 증상 2: API Rate Limit

```
[ERROR] (#80004) There have been too many calls to this ad-account.
[INFO] 60초 대기 후 재시도...
```

## 원인

Meta API 호출 한도 (광고계정당 시간당 약 200건). 자동 백오프로 대기 중.

## 해결

스크립트가 자동으로 대기 + 재시도하므로 추가 조치 불필요. 다만:

- 동일 광고계정에 여러 자동화가 동시 실행 중이면 분산 필요
- `--since`/`--until` 으로 30일치 한 번에 백필하면 한도 초과 가능 → 7일 단위로 나눠서 실행 권장

## 증상 3: 데이터 0원 / 없음

```
[자사몰] 데이터 수집 중... (2026-04-26 ~ 2026-04-27)
  → 해당 기간 데이터 없음 (광고 집행 없거나 권한 확인 필요)
```

## 원인

- 해당 기간에 광고 집행 안 됨 (정상)
- account_id 가 잘못됨
- 토큰에 해당 계정 권한 없음

## 해결

`brand_config/{브랜드}.yaml` 의 `account_id` 확인:

```yaml
channels:
  meta:
    accounts:
      own:
        account_id: "act_901839975672999"   # ← 정확한 ID 인지 확인
```

광고 관리자에서 본인 계정 ID 확인:
- 광고관리자 URL: `https://business.facebook.com/adsmanager/manage/?act=901839975672999&...`
- `act=` 뒤 숫자가 ID. yaml 에는 `act_` prefix 붙여서 입력.

## 관련 코드

- `scripts/fetchers/meta_fetcher.py` - `api_get()`, 토큰 만료 처리 (line 130~)
