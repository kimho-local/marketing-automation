# Cafe24 토큰 만료 / 갱신 실패

## 증상

```
[ERROR] 토큰 갱신 실패 (HTTP 400): {"error":"invalid_grant", ...}
[ERROR] 카페24 데이터 수집 실패: ...
```

또는

```
[ERROR] cafe24_token.json 파일 없음. 먼저 cafe24_get_token.py 실행 필요.
```

## 원인

Cafe24 access_token 은 2시간, refresh_token 은 14일 만료. 14일간 미사용 시 둘 다 폐기됨.

## 진단

토큰 파일 확인:

```bash
type config\renk_cafe24_token.json    (Windows)
cat config/renk_cafe24_token.json     (Mac)
```

`expires_at` 필드의 시각 확인.

## 해결

### Case 1: refresh_token 도 만료된 경우 (가장 흔함)

토큰 신규 발급 절차 진행.

```bash
# 1. 본인 브랜드 Cafe24 관리자 로그인 후 인증 URL 접속
#    https://{mall_id}.cafe24api.com/api/v2/oauth/authorize?response_type=code&client_id={CLIENT_ID}&state=app_install&redirect_uri={REDIRECT_URI}&scope=mall.read_application,mall.read_order,mall.read_product

# 2. 승인 후 리다이렉트 URL 의 ?code=xxxxx 부분 복사

# 3. 토큰 발급
py -m scripts.fetchers.cafe24_get_token --brand renk
# 프롬프트에 코드 붙여넣기
```

### Case 2: client_secret 변경 후 (호진님 보안 권고로 재발급한 경우)

`config/{브랜드}_cafe24_token.json` 의 `client_secret` 을 새 값으로 교체.
이후 위 Case 1 절차로 재발급.

### Case 3: client_id / client_secret / redirect_uri 누락

```
[ERROR] config/renk_cafe24_token.json 에 client_id/client_secret 누락.
        cafe24_get_token.py 가이드 참고하여 한 번만 추가하세요.
```

→ `Cafe24_token_migration.md` 참고하여 토큰 파일에 3개 필드 수동 추가.

## 예방

- 14일 이상 휴가 시 출근 첫날 즉시 1회 실행하여 토큰 갱신
- 자동화: Windows 작업 스케줄러로 매일 1회 실행하면 토큰이 자동으로 14일 갱신됨

## 관련 코드

- `scripts/fetchers/cafe24_fetcher.py` - `refresh_access_token()`
- `scripts/fetchers/cafe24_get_token.py` - 신규 발급 / 수동 갱신
