# 트러블슈팅 인덱스

자주 발생하는 에러를 카테고리별로 정리.

## 매체별

| 파일 | 다루는 증상 |
|------|------|
| `cafe24_token_expired.md` | Cafe24 토큰 만료, refresh_token 재발급, client_secret 변경 |
| `meta_api_token.md` | Meta 액세스 토큰 만료, Rate Limit, 데이터 0원 |
| `ga4_credentials.md` | GA4 인증 파일, property_id, refresh_token 만료 |
| `naver_sa_no_data.md` | 네이버 검색광고 401, 데이터 없음, 브랜드검색 일할 |
| `smartstore_oauth.md` | bcrypt 누락, 401, 결제자수/주문건수 차이 |

## 출력 단계별

| 파일 | 다루는 증상 |
|------|------|
| `google_sheets_permission.md` | 시트 403, spreadsheet_id 오타, 시트 자동 생성 |

## Cowork 플러그인 사용 시

플러그인 자체에 `run-pipeline` 트러블슈팅 스킬이 있습니다. 콘솔 로그를 그대로 복사 → 채팅창에 붙여넣고 "이 에러 분석해주세요" 입력 시 자동 진단.

## 그 외 사항

위 문서에 없는 에러는 다음 정보와 함께 호진님께 공유:

1. 실행 명령어 (정확히)
2. 콘솔 출력 전체 (스택 트레이스 포함)
3. `brand_config/{브랜드}.yaml` 의 channels / stores 섹션
4. 어제 / 그제 실행 시는 정상이었는지

→ Slack DM 또는 이슈 트래커 (있다면) 에 등록.
