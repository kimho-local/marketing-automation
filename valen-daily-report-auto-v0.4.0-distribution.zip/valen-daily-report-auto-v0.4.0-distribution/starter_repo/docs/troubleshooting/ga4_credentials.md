# GA4 인증 / 속성 ID 오류

## 증상 1: 인증 파일 없음

```
[ERROR] GA4 인증 파일 없음: renk_ga4_credentials.json
        ga4_auth_setup.py 또는 docs/api-guides 가이드 따라 발급 필요.
```

## 해결

`config/{브랜드}_ga4_credentials.json` 파일을 다음 형식으로 생성:

```json
{
  "client_id":     "xxxxx.apps.googleusercontent.com",
  "client_secret": "GOCSPX-...",
  "refresh_token": "1//0...",
  "property_id":   "123456789"
}
```

각 값 발급 방법은 `docs/api-guides/광고매체_API_통합_셋업가이드.docx` 참고.

## 증상 2: property_id 누락

```
[ERROR] GA4 property_id 누락. config/{브랜드}_ga4_credentials.json 확인.
```

## 해결

### property_id 찾는 법

1. GA4 좌측 하단 ⚙️ "관리"
2. 좌측 두 번째 칼럼 "속성"
3. "속성 세부정보" → "속성 ID" 9자리 숫자

```json
{
  ...,
  "property_id": "526390956"
}
```

⚠️ 측정 ID(`G-XXXXXX` 형태) 와 헷갈리지 마세요. property_id 는 **숫자만** 9-10자리.

## 증상 3: refresh_token 만료

```
[ERROR] GA4 token refresh 실패 (HTTP 400):
{"error": "invalid_grant", "error_description": "Token has been expired or revoked."}
```

## 원인

- 6개월 이상 미사용
- Google 비밀번호 변경
- "보안 활동" 으로 토큰 폐기

## 해결

OAuth flow 재실행하여 refresh_token 재발급:

1. Google Cloud Console → "사용자 인증 정보" → 본인 OAuth 2.0 클라이언트 ID 확인
2. `ga4_auth_setup.py` (또는 동등한 OAuth flow 스크립트) 실행
3. 브라우저에서 본인 Google 계정 로그인 + 권한 승인
4. 발급된 refresh_token 을 `config/{브랜드}_ga4_credentials.json` 에 갱신

## 증상 4: 데이터가 모두 0

```
2026-04-27: 세션 0 | 사용자 0 | 구매 0건 | 매출 0원
```

## 원인

- 해당 날짜에 트래픽이 실제로 없었음 (정상)
- property_id 가 잘못됨 (다른 GA4 속성 보고 있음)
- 서비스 계정에 GA4 속성 접근 권한 없음

## 해결

GA4 관리 → 속성 → "속성 액세스 관리" → 본인 OAuth 클라이언트 또는 서비스 계정에 **뷰어** 권한 부여.

## 관련 코드

- `scripts/fetchers/ga4_fetcher.py` - `load_credentials()`, `fetch_ga4_data()`
