# Google Sheets 권한 / 인증 오류

## 증상 1: 시트 조회 실패

```
[ERROR] sheets_get HTTP 403:
The caller does not have permission ...
```

## 원인

서비스 계정 이메일에 스프레드시트 편집 권한이 없음.

## 해결

1. `config/{브랜드}_google_sheets_key.json` 열어 `client_email` 값 확인
   ```json
   { "client_email": "xxx-xxx@xxx-project.iam.gserviceaccount.com", ... }
   ```
2. Google Sheets 에서 본인 스프레드시트 열기
3. 우측 상단 "공유" 클릭
4. 위 client_email 추가 → **편집자** 권한 부여
5. "전송" 클릭 (이메일 알림은 OFF 가능)

## 증상 2: spreadsheet_id 불일치

```
[ERROR] sheets_get HTTP 404: Requested entity was not found.
```

## 원인

`config/{브랜드}_google_sheets_config.json` 의 `spreadsheet_id` 가 잘못됐거나, 시트가 삭제됨.

## 해결

스프레드시트 URL 의 ID 부분 재확인:

```
https://docs.google.com/spreadsheets/d/1abcDEFghi.../edit#gid=0
                                       ^^^^^^^^^^^^^
                                       ← 이 부분이 spreadsheet_id
```

`config/{브랜드}_google_sheets_config.json`:
```json
{ "spreadsheet_id": "1abcDEFghi..." }
```

## 증상 3: 서비스 계정 키 만료 / 무효

```
[ERROR] google_sheets 인증 실패
The provided authorization grant is invalid, expired, revoked
```

## 해결

Google Cloud Console 에서 서비스 계정 키 재발급:

1. https://console.cloud.google.com/iam-admin/serviceaccounts
2. 본인 서비스 계정 선택 → "키" 탭
3. "키 추가" → "JSON" 형식
4. 다운로드된 JSON 을 `config/{브랜드}_google_sheets_key.json` 로 교체
5. 기존 키는 "삭제" (보안)

## 증상 4: 시트 이름 불일치 (헤더 누락)

```
[AUTO] 시트 'META 자사몰' 생성 + 헤더 기입 완료
```

→ 이건 정상 메시지. 첫 실행 시 자동으로 시트 7종 생성됨.

만약 본인이 수동으로 시트 이름을 바꿨다면 (예: "Meta 자사몰" → "메타_자사몰"), 자동화가 새 시트를 또 만들어 중복 발생. 시트 이름은 코드의 `SHEET_HEADERS` 키와 일치해야 함:

| 정확한 시트 이름 |
|----------------|
| META 자사몰 |
| META 스마트스토어 |
| 네이버 SA |
| 카페24 커머스 |
| 카페24 상품TOP |
| Google Ads |
| 스마트스토어 커머스 |

## 관련 코드

- `scripts/writers/google_sheets_writer.py` - `SHEET_HEADERS`, `get_sheet_names()`
