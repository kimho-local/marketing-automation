# 스마트스토어 커머스 API 오류

## 증상 1: bcrypt 패키지 없음

```
[ERROR] bcrypt 패키지 필요: pip install bcrypt
```

## 해결

```bash
py -m pip install bcrypt
```

또는 `requirements.txt` 재설치:

```bash
py -m pip install -r requirements.txt
```

## 증상 2: 인증 파일 없음

```
[ERROR] renk_smartstore_credentials.json 파일 없음.
        스마트스토어 커머스 API 가이드 참고하여 발급 후 위 경로에 배치.
```

## 해결

### 시크릿 파일 형식

`config/{브랜드}_smartstore_credentials.json`:

```json
{
  "client_id":     "스마트스토어 커머스 API 애플리케이션 ID",
  "client_secret": "Client Secret"
}
```

### 발급 절차

1. 네이버 커머스 API 센터 (https://apicenter.commerce.naver.com/) 접속
2. 본인 사업자 계정 로그인
3. 좌측 메뉴 → "API 애플리케이션" → "애플리케이션 등록"
4. 발급된 **애플리케이션 ID** 와 **Client Secret** 을 위 JSON 에 입력

## 증상 3: 401 Unauthorized

```
[ERROR] 토큰 발급 실패 (HTTP 401)
```

## 원인

- client_secret 이 잘못됨 (앞뒤 공백, 특수문자 누락 흔함)
- 애플리케이션이 비활성 상태
- bcrypt 서명 생성 실패

## 해결

1. 네이버 커머스 API 센터에서 client_secret 재확인 (전체 복사)
2. 애플리케이션 상태가 "활성" 인지 확인
3. PC 시간 동기화 (시스템 시간이 너무 어긋나면 서명 실패)

## 증상 4: 결제자 수가 주문 건수와 안 맞음

```
[집계] 결제: 1,058,070원(상품 35건, 주문 28건, 결제자 28명)
```

## 동작

- **상품 건수**: 주문에 포함된 상품 옵션의 개별 건수 (1주문에 여러 상품 있으면 합산)
- **주문 건수**: 주문번호 기준 (1주문 = 1건)
- **결제자 수**: 동일 구매자 ID 중복 제거

이건 정상 동작. 한 사람이 같은 날 여러 주문하면 결제자 수 < 주문 건수.

## 증상 5: 환불이 다음 날에 잡힘

```
[2026-04-26] 환불: 119,600원(3건)
```

해당 날짜에 결제는 0이고 환불만 있는 경우 → 이전 날짜 주문이 26일에 환불된 것. 정상.

## 관련 코드

- `scripts/fetchers/smartstore_fetcher.py` - `TokenManager`, `fetch_smartstore_data()`
