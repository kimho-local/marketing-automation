# Cafe24 토큰 파일 마이그레이션 가이드

기존 Re:NK 환경에서 starter repo 로 옮길 때 1회 작업입니다.

## 변경 요약

| 항목 | 기존 (Re:NK 운영) | 신규 (starter) |
|------|------|------|
| client_id, client_secret | `cafe24_api_fetcher.py` 코드 하드코딩 | `config/{브랜드}_cafe24_token.json` 통합 |
| mall_id | 코드 하드코딩 | `brand_config/{브랜드}.yaml` |
| redirect_uri | 코드 하드코딩 | `config/{브랜드}_cafe24_token.json` |
| access_token, refresh_token, expires_at | `config/renk_cafe24_token.json` | 동일 (변경 없음) |

## 호진님 1회 마이그레이션 작업

### Step 1. 기존 토큰 파일 백업

```
config/renk_cafe24_token.json  →  복사본 보관
```

### Step 2. 토큰 파일에 client 정보 3개 추가

기존 파일을 열어 다음 3개 키를 **추가**합니다 (기존 access_token / refresh_token / expires_at 는 그대로 둡니다):

```json
{
  "client_id":     "LzxcZZ7HMFEnzlltfgvgOE",
  "client_secret": "38aX5qPICVzrdlreBRwaqE",
  "redirect_uri":  "https://www.re-nk.co.kr",

  "access_token":  "(기존 값 유지)",
  "refresh_token": "(기존 값 유지)",
  "expires_at":    "(기존 값 유지)",
  "scopes":        [...]
}
```

### Step 3. 검증

```bash
python scripts/utils/config_loader.py renk
```

다음과 같이 ✓ 표시되면 OK.

```
[시크릿 로드 상태]
  ✓ cafe24
```

### Step 4. fetcher 실행 테스트

```bash
python -m scripts.fetchers.cafe24_fetcher --brand renk --test
```

## 보안 권고

호진님의 client_secret 이 이전 코드에 평문으로 박혀 있었으므로, **Cafe24 개발자센터에서 client_secret 재발급**을 권장합니다.

재발급 절차:
1. Cafe24 개발자센터 → 본인 앱 → 인증정보
2. Client Secret 재발급 클릭
3. 새 값을 토큰 파일에 갱신
4. (Cafe24의 경우 client_secret 변경 시 기존 access_token/refresh_token 도 폐기되므로) `cafe24_get_token.py` 신규 발급 절차 다시 진행
