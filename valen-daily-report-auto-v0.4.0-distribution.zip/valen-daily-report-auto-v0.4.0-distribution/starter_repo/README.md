# Valen Brand Marketing — 데일리 리포트 자동화 Starter

브랜드 광고·매출 데이터 통합 수집 + Cowork 플러그인 연동 자동 발행 시스템.

리엔케이(Re:NK) 8개월 안정화 운영 환경을 기반으로 다른 브랜드도 그대로 사용 가능하게 일반화된 starter repo 입니다.

---

## 🚀 신규 브랜드 셋업 — 가장 빠른 5단계

### Step 1. 필수 프로그램 설치 (최초 1회, 약 5분)
- **Python 3.10 이상**: https://www.python.org/downloads/ (설치 시 ☑ "Add Python to PATH" 체크 필수)
- **Node.js LTS**: https://nodejs.org/

설치 확인:
```
python --version
node --version
```

### Step 2. starter_repo 압축 풀기 + 의존성 설치 (5분)
1. 본 starter_repo 폴더를 원하는 위치에 압축 풀기 (예: `C:\Users\{내이름}\Documents\starter_repo`)
2. cmd(명령 프롬프트)에서 폴더로 이동 후 의존성 설치:

```
cd C:\Users\{내이름}\Documents\starter_repo
pip install -r requirements.txt
npm install
```

### Step 3. Cowork 플러그인 설치 + 워크스페이스 연결 (3분)
1. Claude 데스크톱 앱 → Cowork 모드 진입
2. 관리자에게 받은 `daily-report-auto-v0.3.0.plugin` 파일을 Cowork 채팅창에 드래그 앤 드롭 → "설치" 클릭
3. 코워크 좌측 하단 "폴더 선택" → **starter_repo 폴더 지정** (이 연결로 이후 데이터 파일 자동 탐색됨)

### Step 4. setup-wizard 자동 실행 (10~15분)
코워크 채팅에 다음 한 마디 입력:

```
처음 시작
```

`setup-wizard` 스킬이 자동 호출되어 9단계 카드로 안내:
- 브랜드 정보 입력 (이름·코드·담당자)
- 운영 매체 선택 (Meta·Google Ads·네이버 SA·GA4)
- 판매 채널 선택 (카페24·스마트스토어)
- 보고 도구 선택 (Notion / Slack / docx만 / 데이터 분석만)
- **`brand_config/{본인브랜드코드}.yaml` 자동 생성**
- 필요한 시크릿 파일 리스트 + 발급 가이드
- 첫 검증 + 첫 발행 시도

**별도 가이드 문서를 미리 읽지 않아도 wizard 한 흐름으로 완성됩니다.**

### Step 5. 매일 운영
```
report.bat              # 어제자 데이터 자동 수집 → JSON + docx 생성
```
그다음 Cowork 에서:
```
어제 노션 발행해줘      # 선택한 보고 도구에 따라 다른 스킬 호출
```

---

## 📚 수동 셋업 (코워크 사용이 어려운 경우 fallback)

setup-wizard 없이 직접 셋업하고 싶다면:

1. `brand_config/template.yaml.example` 을 `brand_config/{본인브랜드코드}.yaml` 로 복사
2. 메모장으로 열어 본인 브랜드 정보로 수정
3. `config/SECRETS_REQUIRED.md` 참고하여 필요한 시크릿 파일 발급 후 `config/` 폴더에 배치
4. 검증 명령:
   ```
   python scripts/utils/config_loader.py {본인브랜드코드}
   ```
   모두 ✓ 표시 나오면 완료
5. 첫 실행:
   ```
   python scripts/run_daily.py --brand {본인브랜드코드}
   ```

---

## 동작 흐름

```
[로컬 PC]                              [Cowork 플러그인]
  │                                         │
  ├ report.bat 더블클릭                       │
  │   ↓                                       │
  ├ 매체별 데이터 수집 (활성 매체만)            │
  │   ↓                                       │
  ├ Google Sheets 아카이빙 (선택)             │
  │   ↓                                       │
  ├ docx 보고서 생성                          │
  │     data/report_data_{date}.json          │
  │     reports/{prefix}_Daily_Report.docx    │
  │                                           │
  └─ Cowork 워크스페이스 자동 탐색 ─────→ analyze-data
                                            notion-daily-publisher
                                            (선택한 도구별 분기)
```

각 매체/스토어는 `brand_config/{브랜드}.yaml` 의 `enabled: true/false` 로 on/off.
보고 도구(노션/슬랙/docx/분석만)는 `report_tool` 필드로 선택.

---

## 폴더 구조

```
.
├ brand_config/                          브랜드별 운영 설정 (.gitignore 보호)
│  ├ template.yaml.example                ← 신규 브랜드 메인 템플릿 ★
│  └ _examples/
│     └ renk.yaml.example                 ← 참고용 (호진 님 리엔케이 디폴트값)
│
├ config/                                시크릿 .json (.gitignore 보호)
│  └ SECRETS_REQUIRED.md                  ← 어떤 시크릿이 필요한지 명세
│
├ scripts/
│  ├ run_daily.py                        메인 진입점
│  ├ fetchers/                           매체별 데이터 수집
│  │  ├ meta_fetcher.py
│  │  ├ cafe24_fetcher.py
│  │  ├ cafe24_get_token.py
│  │  ├ cafe24_top_products.py
│  │  ├ smartstore_fetcher.py
│  │  ├ naver_sa_fetcher.py
│  │  ├ google_ads_fetcher.py
│  │  └ ga4_fetcher.py
│  ├ writers/
│  │  ├ google_sheets_writer.py           시트 SKIP/FORCE 분기 아카이빙
│  │  └ generate_daily_report.js          docx 생성기 (Node.js)
│  ├ publishers/
│  │  └ slack_uploader.py                 Slack v2 API 업로드
│  ├ utils/
│  │  ├ config_loader.py                  brand_config + 시크릿 통합 로드
│  │  ├ active_brand.py                   프로세스 단위 브랜드 컨텍스트
│  │  └ logger.py
│  └ legacy/
│     └ meta_processor.py                기존 CSV 기입 도구 (보관용)
│
├ data/                                  수집 raw + report json (.gitignore)
├ reports/                               생성된 docx (.gitignore)
├ logs/                                  실행 로그 (.gitignore)
│
├ docs/
│  ├ api-guides/                         매체별 API 발급 가이드
│  └ troubleshooting/                    ★ 에러 발생 시 첫 참조
│     ├ README.md
│     ├ cafe24_token_expired.md
│     ├ meta_api_token.md
│     ├ ga4_credentials.md
│     ├ naver_sa_no_data.md
│     ├ smartstore_oauth.md
│     └ google_sheets_permission.md
│
├ report.bat                             일일 실행 (Windows)
├ slack.bat                              Slack 단독 발행
├ requirements.txt                       Python 의존성
├ package.json                           Node.js 의존성
├ .gitignore
└ README.md (본 문서)
```

---

## 매일 운영

### 단일 명령어

```bash
report.bat                           # 어제자 데이터 자동 처리 (기본 브랜드)
report.bat 2026-04-27                # 특정 날짜
report.bat 2026-04-27 serene         # 특정 날짜 + 브랜드 지정
slack.bat                            # Slack 단독 발행 (이미 생성된 docx)
```

### Cowork 플러그인 연동

본인 Cowork 프로젝트에 플러그인 첨부 후, 매일 아침:

```
1. report.bat 더블클릭                    (1초 + 30~60초 대기)
2. Cowork 에서: "어제 노션 발행해줘"
   → 워크스페이스에 연결된 starter_repo 의 data/ 폴더 자동 탐색
   → 선택한 보고 도구(notion/slack/docx/analyze) 에 맞는 스킬 호출
3. 종합 코멘트 입력 (사용자 영역)
```

---

## 지원 매체

| 매체 | 데이터 | 일반화 |
|------|--------|------|
| Meta (자사몰/스마트스토어 광고계정 분리 운영 가능) | 광고비, 노출, 클릭, 전환, 매출, CPAS | ✅ |
| Google Ads (P-Max, 디멘드젠, 검색) | 광고비, 클릭, 전환, 매출 | ✅ |
| 네이버 검색광고 (파워링크/쇼핑/브랜드) | 광고비, 클릭, 전환, BS 일할환산 | ✅ |
| GA4 | 세션, 사용자, 채널별, 퍼널, 랜딩페이지 | ✅ |
| Cafe24 자사몰 | 결제, 환불, 순매출, TOP 상품, 첫구매/재구매 | ✅ |
| 네이버 스마트스토어 | 결제, 환불, 순매출, 결제자수 | ✅ |
| 카카오 모먼트 | - | 🚧 v1.1 |
| 자체 구축 자사몰 | - | 🚧 v1.1 |
| Twitter/X 광고 | - | 🚧 v1.2 |

---

## 핵심 설계 원칙

1. **brand_config = 단일 진실 공급원 (SSOT)**
   매체 활성/비활성, 광고계정 ID, mall_id, 시트 ID 등 모든 브랜드별 설정은 yaml 한 파일에서 관리.

2. **lazy init 패턴**
   모든 fetcher 는 모듈 import 시점에는 빈 값 → 첫 함수 호출 시점에 brand_config 에서 값 채움. 시크릿이 모듈 로드 시점에 노출되지 않음.

3. **시크릿은 코드 밖에**
   어떤 시크릿도 코드에 박혀 있지 않음. 모두 `config/` 폴더의 별도 json 파일.

4. **자동 영역과 사용자 영역의 분리**
   데이터 정리는 도구가 자동화, 의미 부여(인사이트)는 사람의 영역. 종합 코멘트는 사용자가 직접 작성.

---

## 보안

| 항목 | 처리 |
|------|------|
| Meta 액세스 토큰 fallback | 코드에서 완전 제거 ✅ |
| Cafe24 client_id/secret 코드 하드코딩 | secrets 파일로 이동 ✅ |
| Smartstore client_id/secret fallback | 코드에서 완전 제거 ✅ |
| GA4 property_id fallback | 코드에서 완전 제거 ✅ |
| 모든 시크릿 .gitignore 보호 | `config/` 폴더 전체 + 패턴 추가 ✅ |
| brand_config (운영 식별값) | `*.yaml` git 제외, `*.yaml.example` 만 커밋 ✅ |

---

## 버전 히스토리

- **v1.1** (2026-05-24) — 신규 사용자 진입 일반화
  - `brand_config/template.yaml.example` 신규 (메인 템플릿)
  - 기존 renk.yaml.example 은 `brand_config/_examples/` 로 격리
  - `config/SECRETS_REQUIRED.md` 신규 (시크릿 발급 명세)
  - 코드 잔재 정리 (cafe24 운영 시작일 하드코딩 → 자동 계산, smartstore 에러 메시지 변수화, TOP 상품 [:3] 슬라이스 제거)
  - README 재배치 — 신규 브랜드 셋업 5단계 1순위
  - daily-report-auto-v0.3.0.plugin 의 setup-wizard 와 연동

- **v1.0.1** (2026-05-01) — 호진 / Re:NK 기반 첫 일반화
  - 매체 7개 + 자사몰 2종 일반화
  - 보안 이슈 4건 처리 (Meta 토큰, Cafe24 secret, Smartstore secret, GA4 property)
  - 환경 설정 가이드 3종 + 트러블슈팅 6종 동봉
