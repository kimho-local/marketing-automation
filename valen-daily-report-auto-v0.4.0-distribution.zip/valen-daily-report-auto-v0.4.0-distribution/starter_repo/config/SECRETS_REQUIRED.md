# config/ 폴더 — 필요한 시크릿 파일 명세

이 폴더에는 광고 매체·자사몰 API 접속용 시크릿 파일(JSON) 들이 들어갑니다.
**모든 시크릿은 본인 PC에만 두고 절대 git/Slack/이메일로 공유하지 마세요.**

> 💡 **가장 쉬운 방법**: 코워크에서 `처음 시작` 입력 → `setup-wizard` 가 어떤 시크릿이 필요한지 + 어떻게 발급하는지 자동 안내합니다.

---

## 파일명 규칙

`{본인브랜드코드}_{매체}_{종류}.json` 형식.

예시 (브랜드 코드 = `serene`):
- `serene_meta_credentials.json`
- `serene_naver_credentials.json`
- `serene_ga4_credentials.json`
- ...

---

## 매체별 필요 파일 — 운영 매체에 따라 다름

본인 brand_config yaml 의 `enabled: true` 항목만 시크릿이 필요합니다.

### Meta (channels.meta.enabled = true 일 때)

| 파일 | 내용 | 발급 방법 |
|------|------|----------|
| `{brand_code}_meta_credentials.json` | `{"access_token": "EAAxxx..."}` | Meta Business Suite → 비즈니스 설정 → 시스템 사용자 → 토큰 생성 (ads_read 권한) |

📖 가이드: `docs/troubleshooting/meta_api_token.md`

---

### Google Ads (channels.google_ads.enabled = true 일 때)

| 파일 | 내용 | 발급 방법 |
|------|------|----------|
| `{brand_code}_google_ads_credentials.json` | OAuth 클라이언트 + Developer Token + login_customer_id | Google Cloud Console → OAuth 클라이언트 + Google Ads API → Developer Token 신청 |
| `{brand_code}_google_ads_token.json` | refresh_token + access_token | OAuth 동의 화면에서 본인 계정으로 토큰 발급 |

📖 가이드: `docs/api-guides/Google_Ads_OAuth_setup.md` (미구현 — 발급 막힘 시 관리자 호출)

---

### 네이버 SA (channels.naver_sa.enabled = true 일 때)

| 파일 | 내용 | 발급 방법 |
|------|------|----------|
| `{brand_code}_naver_credentials.json` | `{"customer_id": "...", "api_key": "...", "secret_key": "..."}` | 네이버 검색광고 → 도구 → API 사용 관리 → 라이선스 발급 |

📖 가이드: `docs/troubleshooting/naver_sa_no_data.md`

---

### GA4 (channels.ga4.enabled = true 일 때)

| 파일 | 내용 | 발급 방법 |
|------|------|----------|
| `{brand_code}_ga4_credentials.json` | Google Cloud 서비스 계정 키 JSON + `property_id` 필드 추가 | Google Cloud Console → 서비스 계정 키 발급 + GA4 속성에 권한 부여 |

📖 가이드: `docs/troubleshooting/ga4_credentials.md`

---

### 카페24 (stores.cafe24.enabled = true 일 때)

| 파일 | 내용 | 발급 방법 |
|------|------|----------|
| `{brand_code}_cafe24_token.json` | client_id, client_secret, redirect_uri, access_token, refresh_token, expires_at | 카페24 개발자센터 → 앱 생성 → OAuth 인증 |

📖 가이드: `docs/api-guides/Cafe24_token_migration.md`

📞 **회사 관리자에게 발급 요청** (앱 등록 권한 필요)

---

### 스마트스토어 (stores.smartstore.enabled = true 일 때)

| 파일 | 내용 | 발급 방법 |
|------|------|----------|
| `{brand_code}_smartstore_credentials.json` | `{"client_id": "...", "client_secret": "..."}` | 네이버 커머스 솔루션 마켓 → API 센터 → 애플리케이션 생성 |

📖 가이드: `docs/troubleshooting/smartstore_oauth.md`

⚠️ bcrypt 라이브러리 필요: `pip install bcrypt`

---

### Google Sheets (report.google_sheet_id 가 채워져 있을 때)

| 파일 | 내용 | 발급 방법 |
|------|------|----------|
| `{brand_code}_google_sheets_config.json` | `{"spreadsheet_id": "...", "sheet_names": {...}}` | 시트 생성 후 시트 ID 와 시트명 매핑 |
| `{brand_code}_google_sheets_key.json` | Google Cloud 서비스 계정 키 (GA4 와 공유 가능) | 서비스 계정 키 발급 후 시트에 편집자 권한 부여 |

📖 가이드: `docs/troubleshooting/google_sheets_permission.md`

---

### Slack (report.slack_channel_id 채워져 있을 때 또는 report_tool=slack)

| 파일 | 내용 | 발급 방법 |
|------|------|----------|
| `{brand_code}_slack_config.json` | `{"bot_token": "xoxb-...", "channel_id": "..."}` | api.slack.com/apps → 앱 생성 → Bot Token Scopes 설정 |

📞 **Slack 워크스페이스 관리자에게 발급 요청**

---

## 시크릿 검증

모든 시크릿 배치 후 다음 명령으로 검증:

```
python scripts/utils/config_loader.py {본인브랜드코드}
```

예시 (brand_code=serene):
```
python scripts/utils/config_loader.py serene
```

각 시크릿 옆에 `✓` 표시가 나오면 OK. `✗ (비어있음)` 이면 해당 파일이 없거나 형식 오류.

---

## 보안 주의사항

- ❌ 시크릿 파일을 git 에 커밋하지 마세요 (`.gitignore` 가 자동 차단)
- ❌ Slack 채팅·이메일·캡처에 시크릿 내용을 노출하지 마세요
- ❌ 시크릿 파일을 다른 PC 로 단순 복사하지 마세요 (필요 시 안전한 채널로 전달)
- ✅ 시크릿 만료/유출 의심 시 즉시 매체사에서 재발급
